from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func
from datetime import datetime
from sqlalchemy import event, text

# Function to get the current day of the week
def get_current_day():
    return datetime.now().strftime('%A')

class Check(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    date = db.Column(db.Date, default=func.current_date())
    day = db.Column(db.String(10), default=get_current_day())
    check_in_time = db.Column(db.Time)
    check_out_time = db.Column(db.Time)
    time_worked = db.Column(db.Time)  # New column for time worked
    status = db.Column(db.String(15))
    check_in_ip = db.Column(db.String(45))  # New column for check-in IP
    check_out_ip = db.Column(db.String(45))  # New column for check-out IP
    user = db.relationship('User', backref=db.backref('checks', lazy=True))


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))
    first_name = db.Column(db.String(150))
    last_name = db.Column(db.String(150))
    email = db.Column(db.String(150), unique=True)
    job_title = db.Column(db.String(150))
    department = db.Column(db.String(150))
    dob = db.Column(db.Date)
    contact = db.Column(db.String(12))
    
class Request(db.Model):
    req_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), db.ForeignKey('user.username'))
    user = db.relationship('User', backref=db.backref('requests', lazy=True))

    date = db.Column(db.Date)
    day = db.Column(db.String(10))
    r_check_in_time = db.Column(db.Time, nullable=False)
    r_check_out_time = db.Column(db.Time, nullable=False)
    request_datetime = db.Column(db.DateTime)
    r_status = db.Column(db.String(20))
    response_datetime = db.Column(db.DateTime)
    reason = db.Column(db.String(100), nullable=True)
    
class Relation(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True)
    manager = db.Column(db.String(150))


def after_tables_created(target, connection, **kw):
    # Define the SQL queries as text objects
    drop_procedure_query = text("""
        DROP PROCEDURE IF EXISTS employee_attendance_management.mark_absent_users;
    """)

    drop_event1_query = text("""
        DROP EVENT IF EXISTS daily_absent_check_event;
    """)

    drop_event2_query = text("""
        DROP EVENT IF EXISTS update_miss_punch_status;
    """)

    create_procedure_query = text("""
        CREATE PROCEDURE mark_absent_users()
        BEGIN
            DECLARE today_date DATE;
            DECLARE current_day VARCHAR(10);

            SET today_date = CURDATE();
            SET current_day = DATE_FORMAT(today_date, '%W');

            INSERT INTO employee_attendance_management.check (user_id, date, day, status)
            SELECT 
                u.id, 
                today_date, 
                current_day, 
                CASE 
                    WHEN current_day IN ('Saturday', 'Sunday') THEN 'Holiday'
                    ELSE 'Absent'
                END as status
            FROM employee_attendance_management.user u
            LEFT JOIN employee_attendance_management.check c 
            ON u.id = c.user_id AND c.date = today_date
            WHERE c.id IS NULL;
        END;
    """)

    create_event1_query = text("""
        CREATE EVENT IF NOT EXISTS daily_absent_check_event    
        ON SCHEDULE EVERY 1 DAY
        STARTS '2024-06-22 18:30:00'
        DO
            CALL employee_attendance_management.mark_absent_users();
    """)

    create_event2_query = text("""
        CREATE EVENT IF NOT EXISTS update_miss_punch_status
        ON SCHEDULE EVERY 1 DAY
        STARTS '2024-06-22 22:00:00'
        DO
        BEGIN
            UPDATE employee_attendance_management.check
            SET status = 'Miss Punch'
            WHERE check_in_time IS NOT NULL
            AND check_out_time IS NULL;
        END;
    """)

    # Execute each query
    connection.execute(drop_procedure_query)
    connection.execute(drop_event1_query)
    connection.execute(drop_event2_query)
    connection.execute(create_procedure_query)
    connection.execute(create_event1_query)
    connection.execute(create_event2_query)

# Register the event listener to execute after tables are created
event.listen(db.metadata, 'after_create', after_tables_created)